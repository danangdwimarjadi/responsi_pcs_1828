package com.example.responsi2_1876

class EmpModelClass(val id: Int, val name: String, val email: String)